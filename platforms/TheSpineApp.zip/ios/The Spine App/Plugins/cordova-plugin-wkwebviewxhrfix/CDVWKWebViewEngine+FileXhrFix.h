//
//  CDVWKWebViewEngine+FileXhrFix.h
//  HelloCordova
//
//  Created by Connor Pearson on 2/9/17.
//
//

#import "CDVWKWebViewEngine.h"

@interface CDVWKWebViewEngine (FileXhrFix)

@end